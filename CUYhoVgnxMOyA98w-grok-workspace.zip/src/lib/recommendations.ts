import type { Focus } from "@/lib/prefs";

export type Recommendation = {
  title: string;
  detail: string;
  to: "/chat" | "/toolkit" | "/guides";
  hash?: string;
};

/** Destinations that exist today. Guide essays are not linked until they are written. */
export const RECOMMENDATIONS: Record<Focus, Recommendation> = {
  Exams: {
    title: "Talk through exams",
    detail: "Tell the chatbot which papers are coming up and which one worries you most.",
    to: "/chat",
  },
  Workload: {
    title: "Talk through the workload",
    detail: "Describe what is piling up so the chatbot can help you name a first step.",
    to: "/chat",
  },
  "Time management": {
    title: "Talk through your time",
    detail: "Use the chatbot to separate what is due soon from what can wait.",
    to: "/chat",
  },
  Sleep: {
    title: "Sleep reminder",
    detail: "Switch off screens 30 minutes before bed and prepare tomorrow’s bag.",
    to: "/toolkit",
    hash: "sleep",
  },
  "Getting started": {
    title: "Talk about getting started",
    detail: "Tell the chatbot what you are avoiding, and ask for one small first step.",
    to: "/chat",
  },
  Concentration: {
    title: "Reflection on concentration",
    detail: "The self-check asks how often focusing on schoolwork is difficult.",
    to: "/toolkit",
    hash: "check",
  },
  Motivation: {
    title: "Talk about motivation",
    detail: "Say what feels stuck. The chatbot can help you pick one manageable task.",
    to: "/chat",
  },
  "School relationships": {
    title: "Talk about school relationships",
    detail: "You can describe peer or classroom pressure without sharing anyone’s full name.",
    to: "/chat",
  },
  "Emotional pressure": {
    title: "Talk about the pressure",
    detail: "Start with what feels heaviest. Solace is not a counsellor, and the chat can help you sort a school concern.",
    to: "/chat",
  },
};
