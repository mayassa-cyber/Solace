import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export const FOCUSES = [
  "Exams",
  "Workload",
  "Time management",
  "Sleep",
  "Getting started",
  "Concentration",
  "Motivation",
  "School relationships",
  "Emotional pressure",
] as const;

export type Focus = (typeof FOCUSES)[number];
export type ThemeName = "light" | "dark" | "warm";
export type TextSize = "default" | "large";
export type Tone = "calm" | "direct" | "encouraging";
export type Length = "short" | "balanced" | "detailed";

export type Prefs = {
  name: string;
  theme: ThemeName;
  text: TextSize;
  tone: Tone;
  length: Length;
  focuses: Focus[];
  welcomeSeen: boolean;
};

const STORAGE_KEY = "solace.preferences";

export const defaultPrefs: Prefs = {
  name: "",
  theme: "light",
  text: "default",
  tone: "calm",
  length: "balanced",
  focuses: [],
  welcomeSeen: false,
};

type PrefsContextValue = {
  prefs: Prefs;
  ready: boolean;
  update: (patch: Partial<Prefs>) => void;
  toggleFocus: (focus: Focus) => void;
};

const PrefsContext = createContext<PrefsContextValue | null>(null);

function applyPrefs(prefs: Prefs) {
  const root = document.documentElement;
  if (prefs.theme === "light") root.removeAttribute("data-theme");
  else root.dataset.theme = prefs.theme;
  if (prefs.text === "large") root.dataset.text = "large";
  else root.removeAttribute("data-text");
}

function readPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultPrefs;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    const rawFocuses = Array.isArray(parsed.focuses) ? (parsed.focuses as unknown[]) : [];
    const focuses = rawFocuses.flatMap((item): Focus[] => {
      if (item === "Time") return ["Time management"];
      if (typeof item === "string" && (FOCUSES as readonly string[]).includes(item)) {
        return [item as Focus];
      }
      return [];
    });
    return {
      ...defaultPrefs,
      ...parsed,
      name: typeof parsed.name === "string" ? parsed.name.slice(0, 40) : "",
      focuses,
    };
  } catch {
    return defaultPrefs;
  }
}

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(defaultPrefs);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const stored = readPrefs();
    setPrefs(stored);
    applyPrefs(stored);
    setReady(true);
  }, []);

  const api = useMemo<PrefsContextValue>(
    () => ({
      prefs,
      ready,
      update(patch) {
        setPrefs((current) => {
          const next = { ...current, ...patch };
          localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
          applyPrefs(next);
          return next;
        });
      },
      toggleFocus(focus) {
        setPrefs((current) => {
          const focuses = current.focuses.includes(focus)
            ? current.focuses.filter((item) => item !== focus)
            : [...current.focuses, focus];
          const next = { ...current, focuses };
          localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
          return next;
        });
      },
    }),
    [prefs, ready],
  );

  return <PrefsContext.Provider value={api}>{children}</PrefsContext.Provider>;
}

export function usePrefs() {
  const value = useContext(PrefsContext);
  if (!value) throw new Error("usePrefs must be used inside PrefsProvider");
  return value;
}
