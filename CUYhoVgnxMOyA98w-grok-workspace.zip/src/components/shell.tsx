import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/chat", label: "Chat" },
  { to: "/toolkit", label: "Toolkit" },
  { to: "/guides", label: "Student Guides" },
  { to: "/safety", label: "Safety & Support" },
  { to: "/about", label: "About" },
  { to: "/settings", label: "Settings" },
] as const;

function navClass(active: boolean) {
  return (
    "inline-flex min-h-11 items-center px-2.5 text-sm font-bold " +
    (active ? "text-primary" : "text-ink hover:text-primary")
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false);

  return (
    <div className="flex min-h-screen flex-col bg-bg text-ink">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-surface focus:px-4 focus:py-2"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b border-border bg-surface">
        <div className="mx-auto flex min-h-16 max-w-6xl flex-wrap items-center gap-x-1 px-5">
          <Link to="/" className="mr-auto py-3 font-display text-2xl text-primary">
            Solace
          </Link>
          <nav className="hidden items-center lg:flex" aria-label="Primary">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={navClass(pathname === item.to)}
                activeOptions={{ exact: true }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center lg:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
        {open ? (
          <nav className="border-t border-border px-3 py-2 lg:hidden" aria-label="Mobile">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={"flex " + navClass(pathname === item.to)}
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        ) : null}
      </header>

      <div className="flex-1">{children}</div>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 py-8 text-sm text-muted">
          <p>Podar Pearl School, Qatar</p>
          <p>Artificial Intelligence (843)</p>
          <p>Academic Year 2026–2027</p>
          <p>Classes XII MA and XII MB</p>
          <p>Project Guide: Miss Gnana Sherin</p>
          <p className="mt-3">
            This platform offers general student support and educational guidance.
            It is not a substitute for professional help.
          </p>
        </div>
      </footer>
    </div>
  );
}
