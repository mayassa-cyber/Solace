import { useEffect, useState } from "react";

const PHASES = [
  { label: "Breathe in", scale: 1.9 },
  { label: "Hold", scale: 1.9 },
  { label: "Breathe out", scale: 1 },
  { label: "Hold", scale: 1 },
] as const;

export function BreathOrb() {
  const [running, setRunning] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      setStep((current) => current + 1);
    }, 4000);
    return () => window.clearInterval(timer);
  }, [running]);

  const phase = running ? PHASES[step % PHASES.length] : null;

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="grid h-80 w-full place-items-center overflow-hidden">
        <div
          className="orb-motion grid size-32 place-items-center rounded-full bg-primary px-3 text-center text-sm font-bold text-on-primary"
          style={{ transform: `scale(${phase ? phase.scale : 1})` }}
          aria-live="polite"
        >
          {phase ? phase.label : "Ready"}
        </div>
      </div>
      <button
        type="button"
        className="inline-flex min-h-11 items-center justify-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover"
        onClick={() => {
          if (running) {
            setRunning(false);
            setStep(0);
            return;
          }
          setStep(0);
          setRunning(true);
        }}
      >
        {running ? "Stop" : "Start"}
      </button>
    </div>
  );
}
