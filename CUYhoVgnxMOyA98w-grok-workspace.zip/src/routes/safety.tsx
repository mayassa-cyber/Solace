import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/safety")({
  head: () => ({ meta: [{ title: "Safety · Solace" }] }),
  component: SafetyPage,
});

function SafetyPage() {
  return (
    <main id="content" className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="font-display text-page">Safety and privacy</h1>
      <div className="mt-6 rounded-control bg-caution px-5 py-5 text-caution-ink">
        <p>
          This chatbot is an AI. It is <strong>not a counselor or doctor</strong>{" "}
          and cannot diagnose anything. Do not share your full name, address, or
          other private details.
        </p>
        <p className="mt-3">
          If you feel unsafe, hopeless, or think about hurting yourself,{" "}
          <strong>
            talk to a trusted adult or your school counselor right now
          </strong>
          , or contact your local emergency number or a crisis helpline.
        </p>
      </div>
      <div className="mt-8 space-y-5 text-muted">
        <p>
          Messages in the chat are handled by Botpress. This website does not
          include a privacy policy for that service, so do not assume a
          conversation is confidential.
        </p>
        <p>
          Display name, appearance, and other preferences stay in this browser
          only. They are not an account, and they are not sent to the chatbot.
        </p>
      </div>
      <div className="mt-10 divide-y divide-border border-y border-border">
        <article className="py-5">
          <h2 className="font-bold">Quick tip: 4-4-4 breathing</h2>
          <p className="mt-1 text-muted">
            Breathe in for 4, hold for 4, breathe out for 4. Repeat five times.
          </p>
        </article>
        <article className="py-5">
          <h2 className="font-bold">Quick tip: study in blocks</h2>
          <p className="mt-1 text-muted">
            25 minutes of focus, 5 minutes of break. After four rounds, take a
            longer rest.
          </p>
        </article>
        <article className="py-5">
          <h2 className="font-bold">Quick tip: protect sleep</h2>
          <p className="mt-1 text-muted">
            Stop screens 30 minutes before bed. A rested brain remembers more.
          </p>
        </article>
      </div>
    </main>
  );
}
