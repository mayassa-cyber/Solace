import { createFileRoute } from "@tanstack/react-router";
import {
  FOCUSES,
  usePrefs,
  type Length,
  type ThemeName,
  type Tone,
} from "@/lib/prefs";
import { RECOMMENDATIONS } from "@/lib/recommendations";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings · Solace" }] }),
  component: SettingsPage,
});

const THEMES: { id: ThemeName; label: string }[] = [
  { id: "light", label: "Light" },
  { id: "dark", label: "Dark" },
  { id: "warm", label: "Warm" },
];

const TONES: { id: Tone; label: string; detail: string }[] = [
  { id: "calm", label: "Calm", detail: "Gentler wording, still practical." },
  { id: "direct", label: "Direct", detail: "The next step first, with less cushioning." },
  { id: "encouraging", label: "Encouraging", detail: "A realistic note on effort, then a next step." },
];

const LENGTHS: { id: Length; label: string }[] = [
  { id: "short", label: "Short" },
  { id: "balanced", label: "Balanced" },
  { id: "detailed", label: "Detailed" },
];

function choiceClass(on: boolean) {
  return (
    "min-h-11 rounded-control border px-4 text-left font-bold " +
    (on ? "border-primary bg-fill text-primary" : "border-border text-ink")
  );
}

function SettingsPage() {
  const { prefs, update, toggleFocus } = usePrefs();

  return (
    <main id="content" className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="font-display text-page">Settings</h1>
      <p className="mt-3 text-muted">
        Optional. Nothing here requires an account. Choices stay in this browser
        and do not move with you to another device.
      </p>

      <label className="mt-10 block">
        <span className="font-bold">Display name</span>
        <span className="mt-1 block text-sm text-muted">
          A nickname is enough. Leave this blank if you prefer.
        </span>
        <input
          value={prefs.name}
          maxLength={40}
          onChange={(event) => update({ name: event.target.value })}
          className="mt-2 w-full rounded-control border border-border bg-bg px-3 py-3 text-ink"
          placeholder="What should we call you?"
        />
        {prefs.name.trim() ? (
          <p className="mt-2 text-sm text-muted">
            The homepage will greet you as {prefs.name.trim()}.
          </p>
        ) : null}
      </label>

      <fieldset className="mt-10">
        <legend className="font-bold">Appearance</legend>
        <div className="mt-3 flex flex-wrap gap-2">
          {THEMES.map((theme) => (
            <button
              key={theme.id}
              type="button"
              aria-pressed={prefs.theme === theme.id}
              className={choiceClass(prefs.theme === theme.id)}
              onClick={() => update({ theme: theme.id })}
            >
              {theme.label}
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            aria-pressed={prefs.text === "default"}
            className={choiceClass(prefs.text === "default")}
            onClick={() => update({ text: "default" })}
          >
            Default text
          </button>
          <button
            type="button"
            aria-pressed={prefs.text === "large"}
            className={choiceClass(prefs.text === "large")}
            onClick={() => update({ text: "large" })}
          >
            Large text
          </button>
        </div>
      </fieldset>

      <fieldset className="mt-10">
        <legend className="font-bold">How Solace should talk</legend>
        <p className="mt-2 text-sm text-muted">
          Saved here only. These choices do not change the chatbot, because the
          Botpress connection does not receive them.
        </p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {TONES.map((tone) => (
            <button
              key={tone.id}
              type="button"
              aria-pressed={prefs.tone === tone.id}
              className={choiceClass(prefs.tone === tone.id)}
              onClick={() => update({ tone: tone.id })}
            >
              {tone.label}
              <span className="mt-1 block text-sm font-normal text-muted">{tone.detail}</span>
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {LENGTHS.map((length) => (
            <button
              key={length.id}
              type="button"
              aria-pressed={prefs.length === length.id}
              className={choiceClass(prefs.length === length.id)}
              onClick={() => update({ length: length.id })}
            >
              {length.label}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="mt-10">
        <legend className="font-bold">What you want help with</legend>
        <p className="mt-2 text-sm text-muted">
          Selected topics change the suggestions on the homepage. They are not sent
          to the chatbot.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {FOCUSES.map((focus) => (
            <button
              key={focus}
              type="button"
              aria-pressed={prefs.focuses.includes(focus)}
              className={choiceClass(prefs.focuses.includes(focus))}
              onClick={() => toggleFocus(focus)}
            >
              {focus}
            </button>
          ))}
        </div>
        {prefs.focuses.length > 0 ? (
          <ul className="mt-4 space-y-2 text-sm text-muted">
            {prefs.focuses.map((focus) => (
              <li key={focus}>
                <span className="font-bold text-ink">{focus}.</span>{" "}
                {RECOMMENDATIONS[focus].title}
              </li>
            ))}
          </ul>
        ) : null}
      </fieldset>
    </main>
  );
}
