import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BreathOrb } from "@/components/breath-orb";

export const Route = createFileRoute("/toolkit")({
  head: () => ({ meta: [{ title: "Toolkit · Solace" }] }),
  component: ToolkitPage,
});

const QUESTIONS = [
  "I feel worried about school work.",
  "I find it hard to concentrate.",
  "I have trouble sleeping because of school.",
  "I feel overwhelmed by deadlines.",
  "I feel tired or low even after resting.",
];

const NOTES = [
  {
    id: "ground",
    title: "5-4-3-2-1 grounding",
    body: "Name 5 things you see, 4 you feel, 3 you hear, 2 you smell, 1 you taste.",
  },
  {
    id: "pomo",
    title: "Pomodoro study",
    body: "Study 25 minutes, break 5. After four rounds, rest 20 minutes.",
  },
  {
    id: "plan",
    title: "Brain dump",
    body: "Write every task down, then mark each Urgent, Important, or Later.",
  },
  {
    id: "move",
    title: "Move a little",
    body: "A 5-minute walk or stretch clears your head and lifts your mood.",
  },
  {
    id: "talk",
    title: "Talk to someone",
    body: "Tell a friend, parent, teacher, or counselor. Sharing makes stress smaller.",
  },
  {
    id: "sleep",
    title: "Protect your sleep",
    body: "Switch off screens 30 minutes before bed and prepare tomorrow’s bag.",
  },
];

function ToolkitPage() {
  const [answers, setAnswers] = useState<number[]>(QUESTIONS.map(() => 0));
  const [result, setResult] = useState("");

  return (
    <main id="content" className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="font-display text-page">Manage your stress</h1>
      <p className="mt-3 text-muted">Try these right now. They take only a few minutes.</p>

      <div className="mt-10 grid gap-12 lg:grid-cols-2">
        <section id="breathe">
          <h2 className="font-display text-2xl">Guided breathing</h2>
          <p className="mt-2 text-muted">
            Breathe in for 4, hold for 4, breathe out for 4, hold for 4.
          </p>
          <BreathOrb />
        </section>
        <section id="check">
          <h2 className="font-display text-2xl">Stress self-check</h2>
          <p className="mt-2 text-muted">
            Answer from 0 (not at all) to 3 (very often). This is a guide only,
            not a diagnosis.
          </p>
          <div className="mt-4 space-y-4">
            {QUESTIONS.map((question, index) => (
              <label key={question} className="block">
                {question}
                <select
                  className="mt-2 w-full rounded-control border border-border bg-bg px-3 py-2 text-ink"
                  value={answers[index]}
                  onChange={(event) => {
                    const next = [...answers];
                    next[index] = Number(event.target.value);
                    setAnswers(next);
                  }}
                >
                  <option value={0}>0 – Not at all</option>
                  <option value={1}>1 – Sometimes</option>
                  <option value={2}>2 – Often</option>
                  <option value={3}>3 – Very often</option>
                </select>
              </label>
            ))}
          </div>
          <button
            type="button"
            className="mt-4 inline-flex min-h-11 items-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover"
            onClick={() => {
              const total = answers.reduce((sum, value) => sum + value, 0);
              if (total <= 5) {
                setResult(
                  `Low (${total}/15): keep your healthy habits and plan ahead.`,
                );
              } else if (total <= 10) {
                setResult(
                  `Moderate (${total}/15): try breathing or grounding, plan your workload, and talk to a friend or teacher. The chatbot can help.`,
                );
              } else {
                setResult(
                  `High (${total}/15): please talk to a school counselor or trusted adult soon. The chatbot can offer calming support too.`,
                );
              }
            }}
          >
            See my result
          </button>
          {result ? <p className="mt-4 font-bold">{result}</p> : null}
        </section>
      </div>

      <div id="plan" className="mt-12 divide-y divide-border border-y border-border">
        {NOTES.map((note) => (
          <article key={note.id} id={note.id} className="grid gap-2 py-5 sm:grid-cols-[14rem_1fr]">
            <h2 className="font-bold">{note.title}</h2>
            <p className="text-muted">{note.body}</p>
          </article>
        ))}
      </div>
    </main>
  );
}
