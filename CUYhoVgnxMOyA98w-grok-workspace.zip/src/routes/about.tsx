import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About the project · Solace" }] }),
  component: AboutPage,
});

const STEPS = [
  ["Say hello.", "The chatbot introduces itself as an AI and asks how you are feeling."],
  ["Understand.", "It reads your message and identifies the type of stress."],
  ["Gauge the level.", "Low, moderate, or high stress changes how it responds."],
  ["Support.", "You get practical, friendly steps to try."],
  ["Check in.", "It asks whether it helped and offers another option."],
  ["Refer.", "For serious distress, it urges you to contact a real person right away."],
];

const TEAM = [
  ["Yara", "Project Leader"],
  ["Anokhi", "Chatbot Builder"],
  ["Mayassa", "Researcher & Tester"],
  ["Nidah", "Data Expert"],
  ["Shivani", "Designer"],
];

function AboutPage() {
  return (
    <main id="content" className="mx-auto max-w-3xl px-5 py-12">
      <p className="text-sm font-bold text-muted">
        Classes XII MA and XII MB · Academic Year 2026–2027 · Guide: Miss Gnana Sherin
      </p>
      <h1 className="mt-3 font-display text-page">About the project</h1>
      <div className="mt-6 space-y-4">
        <p>
          <strong>Problem:</strong> Many students feel academic stress but have no
          easy, private way to talk about it or learn to manage it.
        </p>
        <p>
          <strong>Solution:</strong> An AI chatbot that gives friendly,
          evidence-informed stress support and connects students to real people
          when needed.
        </p>
        <p>
          <strong>How we built it:</strong> We followed Design Thinking: researched
          student stress, surveyed users, brainstormed ideas, collected and
          simplified stress-management content, built the chatbot in Botpress,
          tested it with classmates and teachers, and improved it.
        </p>
      </div>

      <h2 className="mt-12 font-display text-2xl">What the chatbot does</h2>
      <p className="mt-2 text-muted">
        Built on the Botpress conversational AI platform and designed around
        student needs.
      </p>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-muted">
        <li>Listens. Share how you feel in your own words. It responds with empathy, not lectures.</li>
        <li>Finds the cause. Helps you spot what is behind your stress: exams, workload, time, sleep, or pressure.</li>
        <li>Calms you. Guides breathing, grounding, and short-break techniques you can use right away.</li>
        <li>Helps you plan. Study timetables, prioritising, and exam-preparation tips to feel in control.</li>
        <li>Points to people. Encourages you to talk to a counselor, parent, or trusted adult when you need more help.</li>
      </ul>

      <h2 className="mt-12 font-display text-2xl">How it works</h2>
      <ol className="mt-4 list-decimal space-y-3 pl-5">
        {STEPS.map(([title, body]) => (
          <li key={title}>
            <strong>{title}</strong> {body}
          </li>
        ))}
      </ol>
      <div className="mt-6 overflow-x-auto">
        <table className="w-full min-w-[28rem] border-collapse text-left">
          <thead>
            <tr className="bg-fill">
              <th className="border border-border px-3 py-2">Level</th>
              <th className="border border-border px-3 py-2">What the chatbot does</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-border px-3 py-2">Low</td>
              <td className="border border-border px-3 py-2">
                Encouragement, time-management tips, healthy habits
              </td>
            </tr>
            <tr>
              <td className="border border-border px-3 py-2">Moderate</td>
              <td className="border border-border px-3 py-2">
                Guided breathing or grounding, a study plan, suggests talking to someone
              </td>
            </tr>
            <tr>
              <td className="border border-border px-3 py-2">High</td>
              <td className="border border-border px-3 py-2">
                Caring message and urges contacting a counselor, parent, or emergency help immediately
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <h2 className="mt-12 font-display text-2xl">Data, testing, and limits</h2>
      <div className="mt-4 space-y-4 text-muted">
        <p>
          <strong className="text-ink">Data used.</strong> Stress causes, coping
          techniques, study strategies, sample student messages, tone rules, and
          safety rules.
        </p>
        <p>
          <strong className="text-ink">Testing.</strong> Scenarios such as exam
          panic, heavy workload, poor sleep, low motivation, and serious distress.
        </p>
        <p>
          <strong className="text-ink">Limits.</strong> Cannot diagnose, may
          misread feelings, text only, works best in English.
        </p>
      </div>

      <h2 className="mt-12 font-display text-2xl">
        Connection to the Sustainable Development Goals
      </h2>
      <dl className="mt-4 divide-y divide-border border-y border-border">
        <div className="py-4">
          <dt className="font-bold">SDG 3 · Good Health and Well-Being</dt>
          <dd className="text-muted">
            Our main goal: early, stigma-free mental well-being support for students.
          </dd>
        </div>
        <div className="py-4">
          <dt className="font-bold">SDG 4 · Quality Education</dt>
          <dd className="text-muted">Less stress means better focus, learning, and engagement.</dd>
        </div>
        <div className="py-4">
          <dt className="font-bold">SDG 9 · Innovation</dt>
          <dd className="text-muted">Responsible use of AI to solve a real school problem.</dd>
        </div>
        <div className="py-4">
          <dt className="font-bold">SDG 10 · Reduced Inequalities</dt>
          <dd className="text-muted">
            Free, equal support for every student, including those who stay quiet.
          </dd>
        </div>
      </dl>

      <h2 className="mt-12 font-display text-2xl">Our team</h2>
      <p className="mt-2 text-muted">
        Classes XII MA and XII MB · Guide: Miss Gnana Sherin
      </p>
      <ul className="mt-4 divide-y divide-border border-y border-border">
        {TEAM.map(([name, role]) => (
          <li key={name} className="flex items-baseline justify-between gap-4 py-4">
            <span className="font-bold">{name}</span>
            <span className="text-muted">{role}</span>
          </li>
        ))}
      </ul>
    </main>
  );
}
