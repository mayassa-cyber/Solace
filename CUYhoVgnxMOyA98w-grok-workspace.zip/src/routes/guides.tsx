import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/guides")({
  head: () => ({ meta: [{ title: "Student Guides · Solace" }] }),
  component: GuidesPage,
});

const TIPS = [
  {
    id: "breathing",
    title: "4-4-4 breathing",
    body: "Breathe in for 4, hold for 4, breathe out for 4. Repeat five times.",
  },
  {
    id: "blocks",
    title: "Study in blocks",
    body: "25 minutes of focus, 5 minutes of break. After four rounds, take a longer rest.",
  },
  {
    id: "sleep",
    title: "Protect sleep",
    body: "Stop screens 30 minutes before bed. A rested brain remembers more.",
  },
];

function GuidesPage() {
  return (
    <main id="content" className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="font-display text-page">Student Guides</h1>
      <p className="mt-3 text-muted">
        Short reminders already written for the project.
      </p>
      <div className="mt-8 divide-y divide-border border-y border-border">
        {TIPS.map((tip) => (
          <article key={tip.id} id={tip.id} className="py-5">
            <h2 className="font-bold">{tip.title}</h2>
            <p className="mt-1 text-muted">{tip.body}</p>
          </article>
        ))}
      </div>
    </main>
  );
}
