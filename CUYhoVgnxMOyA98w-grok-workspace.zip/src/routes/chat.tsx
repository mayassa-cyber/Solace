import { createFileRoute } from "@tanstack/react-router";
import { BOT_URL } from "@/lib/bot";

export const Route = createFileRoute("/chat")({
  head: () => ({ meta: [{ title: "Chat · Solace" }] }),
  component: ChatPage,
});

function ChatPage() {
  return (
    <main id="content" className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="font-display text-page">Talk to the chatbot</h1>
      <p className="mt-3 max-w-2xl text-muted">
        It is friendly, and available when the connection is working. Avoid
        sharing your full name or personal details.
      </p>
      <div className="mt-8 overflow-hidden rounded-control border border-border bg-surface">
        <iframe
          title="Student stress management chatbot"
          src={BOT_URL}
          className="chat-frame w-full border-0 bg-surface"
          allow="clipboard-write"
        />
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm">
          <p className="text-muted">
            Chat not loading? Your browser or school network may block embedded
            chats.
          </p>
          <a href={BOT_URL} target="_blank" rel="noopener" className="font-bold text-primary">
            Open chatbot in a new tab
          </a>
        </div>
      </div>
      <p className="mt-4 max-w-2xl text-sm text-muted">
        Preference settings on this website stay in your browser. They are not
        sent to the chatbot.
      </p>
    </main>
  );
}
