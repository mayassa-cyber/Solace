import { createFileRoute, Link } from "@tanstack/react-router";
import { usePrefs } from "@/lib/prefs";
import { RECOMMENDATIONS } from "@/lib/recommendations";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "Solace · Talk it out. Breathe. Plan." }],
  }),
  component: Home,
});

function Home() {
  const { prefs } = usePrefs();
  const name = prefs.name.trim();

  return (
    <main id="content">
      <section className="mx-auto max-w-6xl px-5 py-16 lg:py-24">
        <p className="text-sm font-bold text-muted">
          Podar Pearl School, Qatar · XII MA and XII MB · 2026–2027
        </p>
        <h1 className="mt-4 max-w-3xl font-display text-hero text-ink">
          Feeling stressed about school?
          <span className="mt-3 block">Talk it out. Breathe. Plan.</span>
        </h1>
        <p className="mt-6 max-w-xl text-muted">
          {name ? <span className="text-ink">Hello, {name}. </span> : null}
          Solace brings together conversational support, practical tools, and
          student resources for everyday school stress.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            to="/chat"
            className="inline-flex min-h-11 items-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover"
          >
            Start chatting
          </Link>
          <Link
            to="/toolkit"
            className="inline-flex min-h-11 items-center rounded-control border border-primary px-5 font-bold text-primary"
          >
            Explore the toolkit
          </Link>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <h2 className="font-display text-page">Three places to start</h2>
          <div className="mt-8 divide-y divide-border border-y border-border">
            <article className="grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center">
              <h3 className="font-display text-2xl">Talk</h3>
              <p className="text-muted">
                Say what is going on, in your own words, to the chatbot.
              </p>
              <Link to="/chat" className="font-bold text-primary">
                Start chatting
              </Link>
            </article>
            <article className="grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center">
              <h3 className="font-display text-2xl">Breathe</h3>
              <p className="text-muted">
                A guided cycle: breathe in, hold, breathe out, hold.
              </p>
              <Link to="/toolkit" hash="breathe" className="font-bold text-primary">
                Open breathing
              </Link>
            </article>
            <article className="grid gap-3 py-6 md:grid-cols-[12rem_1fr] md:items-center">
              <h3 className="font-display text-2xl">Plan</h3>
              <p className="text-muted">
                Write every task down, then mark each Urgent, Important, or Later.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-page">Tools you can use now</h2>
        <div className="mt-8 divide-y divide-border border-y border-border">
          <article className="grid gap-3 py-6 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <h3 className="font-bold">Guided breathing</h3>
              <p className="text-muted">Start and stop a four-second breathing cycle.</p>
            </div>
            <Link to="/toolkit" hash="breathe" className="font-bold text-primary">
              Open breathing
            </Link>
          </article>
          <article className="grid gap-3 py-6 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <h3 className="font-bold">Stress self-check</h3>
              <p className="text-muted">
                A short reflection on school stress. It is not a diagnosis.
              </p>
            </div>
            <Link to="/toolkit" hash="check" className="font-bold text-primary">
              Open the self-check
            </Link>
          </article>
        </div>
      </section>

      {prefs.focuses.length > 0 ? (
        <section className="border-t border-border bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-16">
            <h2 className="font-display text-page">Suggested for you</h2>
            <p className="mt-3 max-w-xl text-muted">
              Based on the topics selected in Settings. Change them any time.
            </p>
            <div className="mt-8 divide-y divide-border border-y border-border">
              {prefs.focuses.map((focus) => {
                const item = RECOMMENDATIONS[focus];
                return (
                  <article
                    key={focus}
                    className="grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center"
                  >
                    <h3 className="font-bold">{focus}</h3>
                    <p className="text-muted">
                      <span className="text-ink">{item.title}. </span>
                      {item.detail}
                    </p>
                    <Link to={item.to} hash={item.hash} className="font-bold text-primary">
                      Open
                    </Link>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      ) : null}

      <section className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-page">Student Guides</h2>
        <p className="mt-3 max-w-xl text-muted">
          Short reminders already written for the project: breathing, study blocks,
          and sleep.
        </p>
        <Link to="/guides" className="mt-6 inline-flex font-bold text-primary">
          Open Student Guides
        </Link>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 py-10">
          <p className="max-w-xl text-muted">
            This platform offers general student support and educational guidance.
            It is not a substitute for professional help.{" "}
            <Link to="/safety" className="font-bold text-primary">
              Read Safety & Support
            </Link>
          </p>
        </div>
      </section>
    </main>
  );
}
