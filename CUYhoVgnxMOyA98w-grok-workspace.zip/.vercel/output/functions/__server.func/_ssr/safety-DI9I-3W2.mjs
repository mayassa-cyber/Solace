import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/safety-DI9I-3W2.js
var import_jsx_runtime = require_jsx_runtime();
function SafetyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "mx-auto max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-page",
				children: "Safety and privacy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-control bg-caution px-5 py-5 text-caution-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"This chatbot is an AI. It is ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "not a counselor or doctor" }),
					" ",
					"and cannot diagnose anything. Do not share your full name, address, or other private details."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3",
					children: [
						"If you feel unsafe, hopeless, or think about hurting yourself,",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "talk to a trusted adult or your school counselor right now" }),
						", or contact your local emergency number or a crisis helpline."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-5 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Messages in the chat are handled by Botpress. This website does not include a privacy policy for that service, so do not assume a conversation is confidential." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Display name, appearance, and other preferences stay in this browser only. They are not an account, and they are not sent to the chatbot." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 divide-y divide-border border-y border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold",
							children: "Quick tip: 4-4-4 breathing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: "Breathe in for 4, hold for 4, breathe out for 4. Repeat five times."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold",
							children: "Quick tip: study in blocks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: "25 minutes of focus, 5 minutes of break. After four rounds, take a longer rest."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold",
							children: "Quick tip: protect sleep"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: "Stop screens 30 minutes before bed. A rested brain remembers more."
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { SafetyPage as component };
