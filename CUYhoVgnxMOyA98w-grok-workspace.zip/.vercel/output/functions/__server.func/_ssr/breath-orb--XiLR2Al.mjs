import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/breath-orb--XiLR2Al.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHASES = [
	{
		label: "Breathe in",
		scale: 1.9
	},
	{
		label: "Hold",
		scale: 1.9
	},
	{
		label: "Breathe out",
		scale: 1
	},
	{
		label: "Hold",
		scale: 1
	}
];
function BreathOrb() {
	const [running, setRunning] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const timer = window.setInterval(() => {
			setStep((current) => current + 1);
		}, 4e3);
		return () => window.clearInterval(timer);
	}, [running]);
	const phase = running ? PHASES[step % PHASES.length] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-80 w-full place-items-center overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "orb-motion grid size-32 place-items-center rounded-full bg-primary px-3 text-center text-sm font-bold text-on-primary",
				style: { transform: `scale(${phase ? phase.scale : 1})` },
				"aria-live": "polite",
				children: phase ? phase.label : "Ready"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "inline-flex min-h-11 items-center justify-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover",
			onClick: () => {
				if (running) {
					setRunning(false);
					setStep(0);
					return;
				}
				setStep(0);
				setRunning(true);
			},
			children: running ? "Stop" : "Start"
		})]
	});
}
//#endregion
export { BreathOrb as t };
