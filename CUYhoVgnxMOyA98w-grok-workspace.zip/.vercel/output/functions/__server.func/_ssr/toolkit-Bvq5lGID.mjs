import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BreathOrb } from "./breath-orb--XiLR2Al.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/toolkit-Bvq5lGID.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var QUESTIONS = [
	"I feel worried about school work.",
	"I find it hard to concentrate.",
	"I have trouble sleeping because of school.",
	"I feel overwhelmed by deadlines.",
	"I feel tired or low even after resting."
];
var NOTES = [
	{
		id: "ground",
		title: "5-4-3-2-1 grounding",
		body: "Name 5 things you see, 4 you feel, 3 you hear, 2 you smell, 1 you taste."
	},
	{
		id: "pomo",
		title: "Pomodoro study",
		body: "Study 25 minutes, break 5. After four rounds, rest 20 minutes."
	},
	{
		id: "plan",
		title: "Brain dump",
		body: "Write every task down, then mark each Urgent, Important, or Later."
	},
	{
		id: "move",
		title: "Move a little",
		body: "A 5-minute walk or stretch clears your head and lifts your mood."
	},
	{
		id: "talk",
		title: "Talk to someone",
		body: "Tell a friend, parent, teacher, or counselor. Sharing makes stress smaller."
	},
	{
		id: "sleep",
		title: "Protect your sleep",
		body: "Switch off screens 30 minutes before bed and prepare tomorrow’s bag."
	}
];
function ToolkitPage() {
	const [answers, setAnswers] = (0, import_react.useState)(QUESTIONS.map(() => 0));
	const [result, setResult] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "mx-auto max-w-6xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-page",
				children: "Manage your stress"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Try these right now. They take only a few minutes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-12 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "breathe",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Guided breathing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "Breathe in for 4, hold for 4, breathe out for 4, hold for 4."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreathOrb, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Stress self-check"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Answer from 0 (not at all) to 3 (very often). This is a guide only, not a diagnosis."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-4",
						children: QUESTIONS.map((question, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [question, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "mt-2 w-full rounded-control border border-border bg-bg px-3 py-2 text-ink",
								value: answers[index],
								onChange: (event) => {
									const next = [...answers];
									next[index] = Number(event.target.value);
									setAnswers(next);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: 0,
										children: "0 – Not at all"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: 1,
										children: "1 – Sometimes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: 2,
										children: "2 – Often"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: 3,
										children: "3 – Very often"
									})
								]
							})]
						}, question))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-4 inline-flex min-h-11 items-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover",
						onClick: () => {
							const total = answers.reduce((sum, value) => sum + value, 0);
							if (total <= 5) setResult(`Low (${total}/15): keep your healthy habits and plan ahead.`);
							else if (total <= 10) setResult(`Moderate (${total}/15): try breathing or grounding, plan your workload, and talk to a friend or teacher. The chatbot can help.`);
							else setResult(`High (${total}/15): please talk to a school counselor or trusted adult soon. The chatbot can offer calming support too.`);
						},
						children: "See my result"
					}),
					result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-bold",
						children: result
					}) : null
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "plan",
				className: "mt-12 divide-y divide-border border-y border-border",
				children: NOTES.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					id: note.id,
					className: "grid gap-2 py-5 sm:grid-cols-[14rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: note.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: note.body
					})]
				}, note.id))
			})
		]
	});
}
//#endregion
export { ToolkitPage as component };
