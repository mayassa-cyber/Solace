import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-o5XYHgbB.js
var import_jsx_runtime = require_jsx_runtime();
var BOT_URL = "https://cdn.botpress.cloud/webchat/v3.6/shareable.html?configUrl=https://files.bpcontent.cloud/2026/05/17/14/20260517141818-02O46A88.json";
function ChatPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "mx-auto max-w-6xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-page",
				children: "Talk to the chatbot"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "It is friendly, and available when the connection is working. Avoid sharing your full name or personal details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 overflow-hidden rounded-control border border-border bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: "Student stress management chatbot",
					src: BOT_URL,
					className: "chat-frame w-full border-0 bg-surface",
					allow: "clipboard-write"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Chat not loading? Your browser or school network may block embedded chats."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: BOT_URL,
						target: "_blank",
						rel: "noopener",
						className: "font-bold text-primary",
						children: "Open chatbot in a new tab"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-sm text-muted",
				children: "Preference settings on this website stay in your browser. They are not sent to the chatbot."
			})
		]
	});
}
//#endregion
export { ChatPage as component };
