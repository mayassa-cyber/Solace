import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useOpenSettings, r as usePrefs } from "./router-BtTBg_lJ.mjs";
import { t as BreathOrb } from "./breath-orb--XiLR2Al.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BT0sCJ5O.js
var import_jsx_runtime = require_jsx_runtime();
var ABILITIES = [
	{
		title: "Listens",
		body: "Share how you feel in your own words. It responds with empathy, not lectures."
	},
	{
		title: "Finds the cause",
		body: "Helps you spot what is behind your stress: exams, workload, time, sleep, or pressure."
	},
	{
		title: "Calms you",
		body: "Guides breathing, grounding, and short-break techniques you can use right away."
	},
	{
		title: "Helps you plan",
		body: "Study timetables, prioritising, and exam-preparation tips to feel in control."
	},
	{
		title: "Points to people",
		body: "Encourages you to talk to a counselor, parent, or trusted adult when you need more help."
	}
];
function Home() {
	const { prefs } = usePrefs();
	const openSettings = useOpenSettings();
	const named = prefs.name.trim();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 lg:grid-cols-2 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-muted",
						children: "Podar Pearl School · AI Project 2025–26"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 font-display text-hero text-ink",
						children: ["Feeling stressed about school?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-3 block",
							children: "Talk it out. Breathe. Plan."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-muted",
						children: "An AI chatbot built by students, for students, that listens without judging and shares simple ways to manage academic stress."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/chat",
							className: "inline-flex min-h-11 items-center rounded-control bg-primary px-5 font-bold text-on-primary hover:bg-primary-hover",
							children: "Start chatting"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toolkit",
							className: "inline-flex min-h-11 items-center rounded-control border border-primary px-5 font-bold text-primary",
							children: "Open the toolkit"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreathOrb, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid gap-4 border-t border-border pt-5 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/chat",
							className: "hover:text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-bold",
								children: "Talk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Say what is going on."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/toolkit",
							hash: "breathe",
							className: "hover:text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-bold",
								children: "Breathe"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "A four-second cycle."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/toolkit",
							hash: "plan",
							className: "hover:text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-bold",
								children: "Plan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Urgent, important, later."
							})]
						})
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-5 py-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-page",
						children: "Start with one thing."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 divide-y divide-border border-y border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl",
										children: "Talk"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: "The chatbot introduces itself as an AI and asks how you are feeling."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/chat",
										className: "font-bold text-primary",
										children: "Start chatting"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl",
										children: "Breathe"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: "Breathe in, hold, breathe out, hold. Each part lasts four seconds."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/toolkit",
										hash: "breathe",
										className: "font-bold text-primary",
										children: "Try breathing"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "grid gap-3 py-6 md:grid-cols-[12rem_1fr_auto] md:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl",
										children: "Plan"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: "Write every task down, then mark each Urgent, Important, or Later."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/toolkit",
										hash: "plan",
										className: "font-bold text-primary",
										children: "Sort your work"
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-[minmax(0,22rem)_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-page",
					children: "What Solace helps with"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "Built on the Botpress conversational AI platform and designed around student needs."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "divide-y divide-border border-y border-border",
					children: ABILITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1 py-4 sm:grid-cols-[9rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-bold",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-muted",
							children: item.body
						})]
					}, item.title))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [named ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-bold",
						children: [
							"Hello, ",
							named,
							"."
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: "You can set how Solace looks and talks."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: prefs.focuses.length > 0 ? `You wanted help with ${prefs.focuses.join(", ")}.` : "It is optional, and it stays in this browser."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex min-h-11 items-center font-bold text-primary",
						onClick: openSettings,
						children: named || prefs.focuses.length > 0 ? "Edit preferences" : "Set preferences"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-6xl px-5 py-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						"Solace offers general support only and is not a substitute for professional help.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/safety",
							className: "font-bold text-primary",
							children: "Read this before you use the chat."
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
