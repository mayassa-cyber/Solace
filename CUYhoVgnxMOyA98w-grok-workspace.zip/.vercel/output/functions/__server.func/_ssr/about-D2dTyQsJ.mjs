import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-D2dTyQsJ.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	["Say hello.", "The chatbot introduces itself as an AI and asks how you are feeling."],
	["Understand.", "It reads your message and identifies the type of stress."],
	["Gauge the level.", "Low, moderate, or high stress changes how it responds."],
	["Support.", "You get practical, friendly steps to try."],
	["Check in.", "It asks whether it helped and offers another option."],
	["Refer.", "For serious distress, it urges you to contact a real person right away."]
];
var TEAM = [
	["Yara", "Project Leader"],
	["Anokhi", "Chatbot Builder"],
	["Mayassa", "Researcher & Tester"],
	["Nidah", "Data Expert"],
	["Shivani", "Designer"]
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "mx-auto max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-bold text-muted",
				children: "Class 12 MA · Guide: Ms. Gnana Sherin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-page",
				children: "About the project"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Problem:" }), " Many students feel academic stress but have no easy, private way to talk about it or learn to manage it."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Solution:" }), " An AI chatbot that gives friendly, evidence-informed stress support and connects students to real people when needed."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "How we built it:" }), " We followed Design Thinking: researched student stress, surveyed users, brainstormed ideas, collected and simplified stress-management content, built the chatbot in Botpress, tested it with classmates and teachers, and improved it."] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl",
				children: "What the chatbot does"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Built on the Botpress conversational AI platform and designed around student needs."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 list-disc space-y-2 pl-5 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Listens. Share how you feel in your own words. It responds with empathy, not lectures." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Finds the cause. Helps you spot what is behind your stress: exams, workload, time, sleep, or pressure." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Calms you. Guides breathing, grounding, and short-break techniques you can use right away." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Helps you plan. Study timetables, prioritising, and exam-preparation tips to feel in control." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Points to people. Encourages you to talk to a counselor, parent, or trusted adult when you need more help." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl",
				children: "How it works"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 list-decimal space-y-3 pl-5",
				children: STEPS.map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
					" ",
					body
				] }, title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[28rem] border-collapse text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "bg-fill",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-border px-3 py-2",
							children: "Level"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border border-border px-3 py-2",
							children: "What the chatbot does"
						})]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "Low"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "Encouragement, time-management tips, healthy habits"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "Moderate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "Guided breathing or grounding, a study plan, suggests talking to someone"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "High"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-border px-3 py-2",
							children: "Caring message and urges contacting a counselor, parent, or emergency help immediately"
						})] })
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl",
				children: "Data, testing, and limits"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-4 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-ink",
						children: "Data used."
					}), " Stress causes, coping techniques, study strategies, sample student messages, tone rules, and safety rules."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-ink",
						children: "Testing."
					}), " Scenarios such as exam panic, heavy workload, poor sleep, low motivation, and serious distress."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-ink",
						children: "Limits."
					}), " Cannot diagnose, may misread feelings, text only, works best in English."] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl",
				children: "Connection to the Sustainable Development Goals"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 divide-y divide-border border-y border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-bold",
							children: "SDG 3 · Good Health and Well-Being"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-muted",
							children: "Our main goal: early, stigma-free mental well-being support for students."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-bold",
							children: "SDG 4 · Quality Education"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-muted",
							children: "Less stress means better focus, learning, and engagement."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-bold",
							children: "SDG 9 · Innovation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-muted",
							children: "Responsible use of AI to solve a real school problem."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-bold",
							children: "SDG 10 · Reduced Inequalities"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-muted",
							children: "Free, equal support for every student, including those who stay quiet."
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-12 font-display text-2xl",
				children: "Our team"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Class 12 MA · Guide: Ms. Gnana Sherin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-border border-y border-border",
				children: TEAM.map(([name, role]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: role
					})]
				}, name))
			})
		]
	});
}
//#endregion
export { AboutPage as component };
