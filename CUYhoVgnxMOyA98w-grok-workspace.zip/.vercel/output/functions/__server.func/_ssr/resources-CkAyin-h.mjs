import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources-CkAyin-h.js
var import_jsx_runtime = require_jsx_runtime();
var TIPS = [
	{
		title: "4-4-4 breathing",
		body: "Breathe in for 4, hold for 4, breathe out for 4. Repeat five times."
	},
	{
		title: "Study in blocks",
		body: "25 minutes of focus, 5 minutes of break. After four rounds, take a longer rest."
	},
	{
		title: "Protect sleep",
		body: "Stop screens 30 minutes before bed. A rested brain remembers more."
	}
];
function ResourcesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "mx-auto max-w-3xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-page",
				children: "Student resources"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Short reminders already written for the project."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 divide-y divide-border border-y border-border",
				children: TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: tip.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: tip.body
					})]
				}, tip.title))
			})
		]
	});
}
//#endregion
export { ResourcesPage as component };
