//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BGcInxwz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/chat",
			"/resources",
			"/safety",
			"/toolkit"
		],
		preloads: ["/assets/index-BI1qnWkc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BI1qnWkc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CPfB1EYI.js", "/assets/breath-orb-FuR0ajzV.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DT5lsqH_.js"]
	},
	"/chat": {
		filePath: "/workspace/src/routes/chat.tsx",
		children: void 0,
		preloads: ["/assets/chat-BxKsmv-m.js"]
	},
	"/resources": {
		filePath: "/workspace/src/routes/resources.tsx",
		children: void 0,
		preloads: ["/assets/resources-DwceEiuS.js"]
	},
	"/safety": {
		filePath: "/workspace/src/routes/safety.tsx",
		children: void 0,
		preloads: ["/assets/safety-BeaPsoTG.js"]
	},
	"/toolkit": {
		filePath: "/workspace/src/routes/toolkit.tsx",
		children: void 0,
		preloads: ["/assets/toolkit-cM5DEx2L.js", "/assets/breath-orb-FuR0ajzV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
